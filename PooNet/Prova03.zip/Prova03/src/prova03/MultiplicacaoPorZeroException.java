package prova03;

public class MultiplicacaoPorZeroException extends Exception {
    public MultiplicacaoPorZeroException(String message) {
        super(message);
    }
}


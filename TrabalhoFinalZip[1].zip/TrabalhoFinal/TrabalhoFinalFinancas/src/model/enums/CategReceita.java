package model.enums;

public enum CategReceita {
    SALARIO, 
    DECIMO_TERCEIRO, 
    FERIAS, 
    OUTRAS_RECEITAS
}

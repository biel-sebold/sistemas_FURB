package model.enums;

public enum CategDespesa {
    ALIMENTACAO, 
    TRANSPORTE, 
    RESIDENCIA, 
    SAUDE, 
    EDUCACAO, 
    ENTRETENIMENTO, 
    OUTRAS_DESPESAS
}
